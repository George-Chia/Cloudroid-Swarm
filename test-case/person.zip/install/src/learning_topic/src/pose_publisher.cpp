#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

int main(int argc, char **argv)
{
	ros::init(argc, argv, "velocity_publisher");
	ros::NodeHandle n;
	ros::Publisher p = n.advertise <geometry_msgs::Twist> ("/turtle1/cmd_vel", 10);
	ros::Rate loop_rate(10);
	while (ros::ok())
	{
		geometry_msgs::Twist vm;
		vm.linear.x = 0.5;
		vm.angular.z = 0.2;

		p.publish(vm);
		ROS_INFO("velocity command[%0.2f m/s, %0.2f rad/s]", vm.linear.x, vm.angular.z);
		loop_rate.sleep();
	}
	return 0;
}
