#include <ros/ros.h>
#include "learning_topic/Person.h"

void callback(const learning_topic::Person::ConstPtr& msg)
{
	ROS_INFO("Sbuscribe Person Info: name:%s  age:%d  sex:%d", msg->name, msg->name, msg->sex);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "person_subscriber");
	ros::NodeHandle n;
	ros::Subscriber p = n.subscribe("/person_infooo", 10, callback);
	ros::spin();
	return 0;
}

